---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: 5c0fa478708bf2c9ec3bd0adf95ae3f0_1a508e03857311f19d3f525400f8a581
    ReservedCode1: kwZ0YYMhZuEPxcJW4HKSJCciCM2Y4+e2FI8uQvS16OujyFLRmHFpB6ibIVcLyy9EMT9be0tUHMSNCdcgeNVEJokFgyO1P+ePeM83GHZKSnygpkjxUR6MYcgInnLJgonTq4MDooylMiEtr7uZ5mgLtItJ3JEIgZKtPOFMVzbXDlRANgAwt67xu0pQemY=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: 5c0fa478708bf2c9ec3bd0adf95ae3f0_1a508e03857311f19d3f525400f8a581
    ReservedCode2: kwZ0YYMhZuEPxcJW4HKSJCciCM2Y4+e2FI8uQvS16OujyFLRmHFpB6ibIVcLyy9EMT9be0tUHMSNCdcgeNVEJokFgyO1P+ePeM83GHZKSnygpkjxUR6MYcgInnLJgonTq4MDooylMiEtr7uZ5mgLtItJ3JEIgZKtPOFMVzbXDlRANgAwt67xu0pQemY=
---

# IDP 个人发展计划生成器

根据员工能力差距，自动生成结构化个人发展计划（IDP），基于70-20-10模型产出目标-行动-验收闭环。

## 使用方式

```
用户：「张三的团队管理能力评分2.8，目标岗位是人力资源总监，给他做一份12个月的IDP。」
你：直接按Skill流程生成并输出结构化计划文档。
```

## 流程

### 1. 收集输入
从当前对话提取下列参数，缺失项主动追问：
- 员工姓名
- 当前/目标岗位
- 薄弱能力项清单（能力名称+当前评分，满分5分）
- 发展周期（默认12个月）

没有现成数据时追问，如：「张老师目前团队管理能力2.8分，除了这项，其他哪些能力也需要提升？」

### 2. 生成YAML Frontmatter

```yaml
---
title: 张三·个人发展计划
name: 张三
current_role: 人力资源经理
target_role: 人力资源总监
cycle_months: 12
created: YYYY-MM-DD
---
```

### 3. 计算70-20-10比例

| 岗位层级 | 在岗实践 | 辅导反馈 | 正式学习 |
|---------|---------|---------|---------|
| 基层 | 60% | 20% | 20% |
| 中层 | 70% | 20% | 10% |
| 高层 | 80% | 10% | 10% |

按目标岗位层级选择比例。

### 4. 为每项差距生成发展计划

每条输出以下结构：

```
### [差距项名称]：（当前评分2.8 → 目标评分4.5）

**发展目标**：12个月内，能独立完成[具体可验证的行为]，获得直接上级的认可。

**70% - 在岗实践：**
- [行动描述]（第1-3月）
- [行动描述]（第4-6月）

**20% - 辅导反馈：**
- [行动描述]
- [行动描述]

**10% - 正式学习：**
- [建议课程/认证]

**验收标准：** [可量化的成功标准]
```

### 5. 生成里程碑路线图

按季度拆分：Q1建立基础 → Q2实践深化 → Q3突破提升 → Q4成果固化

### 6. 输出完整文档

按顺序拼接：总览 → 计划明细表 → 里程碑路线图 → 备注提醒。以Markdown文件格式输出。

## 输出示例

```yaml
---
title: 张三个人发展计划
name: 张三
current_role: 人力资源经理
target_role: 人力资源总监
cycle_months: 12
created: 2026-07-22
---
```

**发展总览：** 3项待提升 | 目标：人力资源总监 | 周期：12个月

| 能力项 | 当前 | 目标 | 差距 |
|-------|------|------|------|
| 团队管理 | 2.8 | 4.5 | -1.7 |
| 战略思维 | 3.0 | 4.5 | -1.5 |
| 组织发展 | 2.5 | 4.0 | -1.5 |

（接能力项明细 × N → 里程碑路线图 → 备注提醒）

## 关键原则

1. **只输出计划文档**，不解释生成逻辑
2. **验收标准必须可量化**，避免"提升XX能力"这类模糊表达
3. **70-20-10动作比例**按目标岗位层级严格匹配
4. 已安装**岗位胜任力快速词典**时，优先引用词典中的标准表述
5. 不是用户要求时，**不主动询问**是否做在线搜索、不关联任何外部工具
*（内容由AI生成，仅供参考）*
